package com.example.roomsbuddy.view.activity;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;
import android.widget.Toast;

import com.example.roomsbuddy.R;
import com.example.roomsbuddy.data.BottomSheetDialog;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.roomsbuddy.databinding.ActivityMapsBinding;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        googleMap.addMarker(new MarkerOptions().position(new LatLng(28.551411, 77.123123)).title("$49 USD")).showInfoWindow();
        googleMap.addMarker(new MarkerOptions().position(new LatLng(28.6004104, 77.0461887)).title("$45 USD")).showInfoWindow();
        googleMap.addMarker(new MarkerOptions().position(new LatLng(28.601780, 77.046921)).title("$450 USD")).showInfoWindow();
        googleMap.addMarker(new MarkerOptions().position(new LatLng(28.606553, 77.053262)).title("$43 USD")).showInfoWindow();
        googleMap.addMarker(new MarkerOptions().position(new LatLng(28.584280, 77.058487)).title("$87 USD")).showInfoWindow();
        googleMap.addMarker(new MarkerOptions().position(new LatLng(28.587611, 77.071617)).title("$451 USD")).showInfoWindow();
        googleMap.addMarker(new MarkerOptions().position(new LatLng(28.584800, 77.070871)).title("$64 USD")).showInfoWindow();
        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(@NonNull Marker marker) {
                BottomSheetDialog bottomSheet = new BottomSheetDialog();
                bottomSheet.show(getSupportFragmentManager(),
                        "ModalBottomSheet");
                     return false;
            }
        });
    }
}